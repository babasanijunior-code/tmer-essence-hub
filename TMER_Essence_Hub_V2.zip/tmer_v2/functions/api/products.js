export async function onRequestGet({env}){let {results}=await env.DB.prepare('SELECT * FROM products ORDER BY id DESC').all();return Response.json(results)}
