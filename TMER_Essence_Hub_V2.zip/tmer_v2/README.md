# TMER ESSENCE HUB V2
Cloudflare Pages + Functions + D1 full-stack starter.

Setup: create D1 database `tmer-essence-db`, bind it as `DB`, run `schema.sql`, and create an `ADMIN_PASSWORD` secret. Deploy this repo with Cloudflare Pages Git integration. The `functions/` directory must be at project root.
